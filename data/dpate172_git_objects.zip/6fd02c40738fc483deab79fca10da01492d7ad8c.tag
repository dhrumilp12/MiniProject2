object 19764cd4f7e6812688084015fb3e901fdbaac4d9
type commit
tag v68b
tagger James Matthews <jimim@hotmail.co.uk> 1360579770 +0000

Python 68b Release
