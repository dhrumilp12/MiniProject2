object 9c3e0a5e18da2dacc20d93e8f6ac89cdf546d48c
type commit
tag v1.2.0
tagger Justin Carpentier <jcarpent@laas.fr> 1475066913 +0200

Release of version 1.2.0.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJX67whAAoJEA4EpUnaekDlEKUH/AytWUON2uXum+w4R05PYgwP
G/+ZGY5vPSniCrXff+Df6e0VO5faKmR7iQs3XFx4qR7vCwVgGq6mUXOVCVH/fKz1
Re9G+z4k1bw/i5pvce2+e6ZtmIQ6vUxKrSmRMsrZ7vGoq9M6XSZDL55FGeZ02UtW
auSMtryNVthOZFTRCwh/QrHvq5aeNeGRxtavejblhDb2iXkJfkRFRV3ZHwJOabTA
+2IJp5skCm5dxwQf+D/Ye8Xdsyl/5tWH4OiDzSpS0xyNaOvVF1UKhbv+u0Du6R2j
iWSC/by+YN2dIwlUsb6fKsuQyvygQD9n2DBXdsJCCtuRIf9gsFxvWU9izIosCWQ=
=ToZc
-----END PGP SIGNATURE-----
