object 39638fff487ae300e8320be58ba119565f445f80
type commit
tag v70d
tagger James Matthews <jimim@hotmail.co.uk> 1360584290 +0000

Python 70d Release
