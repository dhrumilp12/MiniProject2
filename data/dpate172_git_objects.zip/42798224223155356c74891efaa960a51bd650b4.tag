object 7a6d4bf1463da85c0e3fc08028205deb4833f1bb
type commit
tag v71e
tagger James Matthews <jimim@hotmail.co.uk> 1360584653 +0000

Python 71e Release
