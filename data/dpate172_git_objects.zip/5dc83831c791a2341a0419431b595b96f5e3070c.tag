object 1b68fef664688fe6696955ed631492d5f47bcdc3
type commit
tag v71c
tagger James Matthews <jimim@hotmail.co.uk> 1360584643 +0000

Python 71c Release
