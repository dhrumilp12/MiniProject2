object aafd6d818382b84433187792a91f45e4f43c4035
type commit
tag v1.2.1
tagger Justin Carpentier <jcarpent@laas.fr> 1476449133 +0200

Release of version 1.2.1.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJYANNtAAoJEA4EpUnaekDlLpoH/3Rk79FsPp6hgFkJGCs6HQK+
x1/bF0hefz3YysvLDklXYlg72WvJ+iFPlbWKt/vvVNxgoK9v+GCnjJ2BMa8epLV3
qUNGaL+XUlYO9vasRpQQl0hFW9Ezjnh6w43IP3iqvOdPnK7vETwA6D893tzumbni
OJxtPqcgaRGcaqUCv4znk/nc++wOv90wV+0WU3RnOSHWeQSJCkuarL4LSr7Y3aND
kY5gQZTo6N3fcPhClqqxSEg8yx9dn8zadQY04wnFabeEBUkAOisWOv7YwYEW5wcv
mCNa9LzbKxjT+S0q03PKAPURxhFNVf38EOLBfPfG4PgOmRLyQoqpsxR9JWuhBGM=
=nGU+
-----END PGP SIGNATURE-----
