object 56202485771f87c7292136c13958e5c9a1f4ed73
type commit
tag v0.20.1
tagger Colin Gillespie <csgillespie@gmail.com> 1372176728 +0100

CRAN version 0.20.1
