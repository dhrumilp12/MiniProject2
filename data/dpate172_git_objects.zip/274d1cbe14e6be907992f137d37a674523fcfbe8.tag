object 1da9993302e984445fc95fb22f6d5744034eada9
type commit
tag v0.20.0
tagger Colin Gillespie <csgillespie@gmail.com> 1370600992 +0100

First CRAN version
