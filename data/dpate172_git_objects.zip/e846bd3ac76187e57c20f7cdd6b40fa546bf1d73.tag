object 01f25c014bd31b63828619464caafac8d70c6eb3
type commit
tag v58
tagger James Matthews <jimim@hotmail.co.uk> 1360579751 +0000

Python 58 Release
