object cc91f963993b5523b5d18253f55a8240b7745218
type commit
tag 1.2.5
tagger Piotr Andzel <pandzel@esri.com> 1397080271 -0700

Release 1.2.5
