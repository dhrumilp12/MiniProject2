object b7da8df01bdc464513d72740298f6c3d9ae89c9d
type commit
tag v76a
tagger James Matthews <jimim@hotmail.co.uk> 1372761872 +0100

Python 76a release, parallelised;
