object 5a4bca31f3b2d34c6a83b26d254233ba36c6912e
type commit
tag v70g
tagger James Matthews <jimim@hotmail.co.uk> 1360584483 +0000

Python 70g Release
