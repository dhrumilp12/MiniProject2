object 1500d4af213e39cbd8da3ef65844da28393e3ad3
type commit
tag v70a
tagger James Matthews <jimim@hotmail.co.uk> 1360583938 +0000

Python 70a Release
