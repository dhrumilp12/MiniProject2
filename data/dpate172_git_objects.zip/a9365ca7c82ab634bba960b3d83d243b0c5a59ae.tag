object 44b85cd7d75c26f7bde1938be91775660b6f73ff
type commit
tag v70i
tagger James Matthews <jimim@hotmail.co.uk> 1360584507 +0000

Python 70i Release
