object 8173716748e85746a976795eb10904bb7108801f
type commit
tag v1.1.0
tagger Valenza Florian <fvalenza@laas.fr> 1454586984 +0100

Pinocchio version 1.1.0
