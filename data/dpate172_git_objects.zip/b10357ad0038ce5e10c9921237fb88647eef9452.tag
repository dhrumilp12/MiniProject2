object 54ab820f174586f6163b98bfb7ccfea62ebe695c
type tag
tag v1.0.0
tagger flforget <florent.forget1@gmail.com> 1429516895 +0200

Release of version 1.0.0
