object c22f42e8f29123591c5bbea33fff760888ec2311
type commit
tag v69a
tagger James Matthews <jimim@hotmail.co.uk> 1360579976 +0000

Python 69a Release
