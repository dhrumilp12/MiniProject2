object 93b0f79bf7b62a0f3d308abf9aa73ce08b2026d9
type commit
tag v71b
tagger James Matthews <jimim@hotmail.co.uk> 1360584627 +0000

Python 71b Release
