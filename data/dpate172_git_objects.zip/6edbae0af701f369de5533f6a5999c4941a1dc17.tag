object 0dfa7c3bab52af9cdd2887d33b9206d552f54898
type commit
tag 0.4
tagger David Ketcheson <dketch@gmail.com> 1346173440 +0100

Version 0.4
