object 5affb24b0b9627dcaf67b179ae58b3a64df83ae5
type commit
tag v1.2.2
tagger Justin Carpentier <jcarpent@laas.fr> 1481016678 +0100

Release of version 1.2.2.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJYRoVmAAoJEA4EpUnaekDla14IAIeC5DTnWP3Xd7MxV7iDTgCh
o34zdhJpyfPxKpwTmw+OWZRbseTj0PQnNv1zFAijQu5FFWyvxwsDDloHhfpovlzZ
xP4yw1ZBRp4wK28MT2835av8y5og5hcw+P5+yXRAzHpc/sXgE5XxqoEVMwXhcGWG
cTeYhXqo8Zpw8AstxGq+U8OEGZerRRyuaPrO4oqz/owBMEdbNHeiTSsjlwKN1T+b
0eczqwhlLp1A7di1FVAKXwuFFQnHxP78UgNBxWAT77jAiV7qMDe0dPpNXpHNnrM+
KkLNDYVi8Jj1R4bnpxOUgly3fu8TXb0HYbSZ7hSLc5Goy6PaEbbl7aObbBr1CZY=
=hI74
-----END PGP SIGNATURE-----
