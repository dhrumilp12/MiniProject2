object 205664f61b492ef549d6f8a2d3132a61c3429653
type commit
tag v72b
tagger James Matthews <jimim@hotmail.co.uk> 1360584671 +0000

Python 72b Release
