object 70f755341157fb364209658d3c02c521189284d2
type commit
tag v73e
tagger James Matthews <jimim@hotmail.co.uk> 1360584696 +0000

Python 73e Release
