object 5b648e137f3eb32da9a83d8333754415610d6758
type commit
tag v78
tagger jhmatthews <jimim@hotmail.co.uk> 1405329708 +0100

Python 78 with version corrected
