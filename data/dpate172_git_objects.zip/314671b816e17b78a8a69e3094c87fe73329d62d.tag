object 220f912538e312c03136a925c248b14f58d8be26
type commit
tag v71a
tagger James Matthews <jimim@hotmail.co.uk> 1360584616 +0000

Python 71a Release
