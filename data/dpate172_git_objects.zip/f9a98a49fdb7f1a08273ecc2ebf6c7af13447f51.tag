object 78eef8c29a00bf0f47bd1d80613a7a4f00ee0845
type commit
tag v1.1.2
tagger Justin Carpentier <jcarpent@laas.fr> 1464353043 +0200

Release of version 1.1.2.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJXSEETAAoJEA4EpUnaekDlLjkIAKPK4tFP4y36cxybZbsFUIuw
BlcBAXdzq6ZOZEF1v0wrdEdl+7ac8GZlQcCCgZNOEBsNnBKwoA3WyM87PnVpt6MV
6qGtIVcchs4oYr49C3TrgNUk4UUNF4e2YAsgkIhvRafQvsf3tQmY3xTk9rY3gsPI
uuRFk4ahWnuFItQCYbvCYS96WQ/6Rv5t2JSFbqckkfqyG2ekZX3JK3vn8Uifv0Rh
eUDXNGyHcYBO+7KJA4ozwbOLHZUdxecvYScivFvMOnXdzAKqAutoaa7HJpsVZG8t
CzPwKH8YewCdJWsBjjRFVafMahVHMmGi/j26H2gfzbPZ3URiA41YlhXFblC5laM=
=L1mH
-----END PGP SIGNATURE-----
