object 375e93a2d264cca6c6e6d1434750684ee1f42368
type commit
tag v1.0
tagger Hannu Parviainen <hpparvi@gmail.com> 1453391403 +0000

v1.0
