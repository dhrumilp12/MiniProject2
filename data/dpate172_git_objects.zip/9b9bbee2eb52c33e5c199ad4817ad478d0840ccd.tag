object 3f754c008f73cef8d7712fea8e4faebf87d883e3
type commit
tag v75b
tagger James Matthews <jimim@hotmail.co.uk> 1370523281 +0100

Python 75b Release
