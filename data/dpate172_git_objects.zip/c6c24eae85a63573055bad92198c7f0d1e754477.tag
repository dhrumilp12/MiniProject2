object eb99e710c885c3deb777405f0c038947075b7386
type commit
tag v71
tagger James Matthews <jimim@hotmail.co.uk> 1360584589 +0000

Python 71 Release
