object fbd993319c92dd407ef8b92cd1f17b2aad1a542f
type commit
tag v72c
tagger James Matthews <jimim@hotmail.co.uk> 1360584684 +0000

Python 72c Release
