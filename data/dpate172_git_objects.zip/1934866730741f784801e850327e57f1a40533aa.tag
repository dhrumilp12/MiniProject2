object 264391de594ba7cb074989928484b420fcbf8868
type commit
tag v1.0-beta.3
tagger Hannu Parviainen <hpparvi@gmail.com> 1452708967 +0000

v1.0-beta.3
