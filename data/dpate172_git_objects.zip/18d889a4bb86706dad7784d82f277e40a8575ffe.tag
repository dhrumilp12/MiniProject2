object b4b059d5fbc3a661440d6a6fafe349eccf3bf5ac
type commit
tag v69c
tagger James Matthews <jimim@hotmail.co.uk> 1360579998 +0000

Python 69c Release
