object 39fcc721403f377e4963459b9f5cc30d5c20225f
type commit
tag v70f
tagger James Matthews <jimim@hotmail.co.uk> 1360584471 +0000

Python 70f Release
