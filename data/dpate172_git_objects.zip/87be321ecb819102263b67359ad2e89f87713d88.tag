object f1eb2208fa646be37fe58b8da0ba559af158f693
type commit
tag v0.17.0
tagger Colin Gillespie <csgillespie@gmail.com> 1369148518 +0100

Tagging version 0.17
