object 80ecf9af3dd50add5d93816aaadf5e9d140b2d11
type commit
tag v1.2.3
tagger Florent Lamiraux florent@laas.fr <florent@laas.fr> 1487004520 +0100

release 1.2.3
