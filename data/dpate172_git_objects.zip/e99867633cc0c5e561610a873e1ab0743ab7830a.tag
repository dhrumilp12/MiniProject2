object 4075af40ebe3a5c38d93a2b6ae3514daa786da09
type commit
tag v1.1.1
tagger Justin Carpentier <jcarpent@laas.fr> 1459502838 +0200

Release of version 1.1.1.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJW/j72AAoJEA4EpUnaekDl0SYH/Rz4CtyznHP1aCPJvxaadbsd
ou0tmac4L67VTuGzqWoUpEZjT0BepWWz2HVT8FeT+yN0YTlzXI7YozVHRCx+A/cd
S/dwCZeSGzZPTldOERYI/RP5dOT8NBlT0tq4rukQDwfSq/mSjrn5jbkqhAIvMIMG
o92DnNGxSPfo9RAYWcUQYy+zyFmXflR1+AlKmkqllap6045kxRzVLWx4vO8Me9Vm
UYCH2fDa2TLXU6SIyRKV1mwkw3MhO3TM7BGKcO1zqtyhzregbTwvMgvV5rWnPDmh
t6gJsA0IVd06fK/DTwUieMnW9PumTmywGJsYTlagdY6gIHYSxSlMyfRlGkb2jQ4=
=4xGO
-----END PGP SIGNATURE-----
