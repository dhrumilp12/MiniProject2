object 43a954b51fd13dd79845eda2186079884b696ed8
type commit
tag v70e
tagger James Matthews <jimim@hotmail.co.uk> 1360584460 +0000

Python 70e Release
