object 27345c40e92c280b2f3509c746f5cd635d110e25
type commit
tag v76b
tagger jhmatthews <jimim@hotmail.co.uk> 1378138813 +0100

Python 76b Release
