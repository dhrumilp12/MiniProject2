object d41d731067134fffaef98dcc3673515167ada697
type commit
tag v68e
tagger James Matthews <jimim@hotmail.co.uk> 1360579875 +0000

Python 68e Release
