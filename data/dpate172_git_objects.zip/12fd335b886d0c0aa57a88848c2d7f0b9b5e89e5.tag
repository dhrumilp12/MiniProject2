object 3af5a209109fc025c6f882b2fc7bda9d3b277223
type commit
tag v1.2.7
tagger Justin Carpentier <jcarpent@laas.fr> 1522685909 +0200

Release of version 1.2.7.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJawlfVAAoJEA4EpUnaekDlNWcH/RvJEgxuzRdMgCJkMAwPFfOX
UBE13C0UoascXgt+x6PZzXHGm2ZFP2x8ZRLOkXUNOUggK+5Tm9lOUbgbK1B3c4Em
XN+i89TxJXLbEJtnVPPadnp+BAYxcRpXk0hITEjlwKD9c8g42D7o68Lzc7AyElYK
CE8lUZ5hSt/6Nf/3zJUv/0t1mQcGAW0Yav99NY1jGiOya4ovcZg9U24+Kc3B8fHv
NcNphAOg1VwyYlcHB1gzhIDbMgHH/Ajo1123BGcwVLn+doXoLqerx1qqxuPIYKzf
Osw+Ja0D+roFd6zkSLfg8bKNGm2xBTJfmjCe7g1RQa4Vv0VVIQdyra207yQIMNg=
=/7SN
-----END PGP SIGNATURE-----
