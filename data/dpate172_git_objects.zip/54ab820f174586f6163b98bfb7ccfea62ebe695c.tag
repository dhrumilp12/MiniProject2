object b7521b2453a689a805c98372553874b4c67c21d4
type commit
tag v1.0.0
tagger flforget <florent.forget1@gmail.com> 1429516705 +0200

Release of version 1.0.0
