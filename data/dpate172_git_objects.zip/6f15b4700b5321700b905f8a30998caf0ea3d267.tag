object e1d0d3c8d3cecb9ac0b2ef896f064e39e3b48b5c
type commit
tag v70c
tagger James Matthews <jimim@hotmail.co.uk> 1360583995 +0000

Python 70c Release
