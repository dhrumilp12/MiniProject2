object c27d5c8701927ddd2372a165c6ed5a21b1e3d62f
type commit
tag v1.2.8
tagger Justin Carpentier <jcarpent@laas.fr> 1526661801 +0200

Release of version 1.2.8.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJa/wKpAAoJEA4EpUnaekDl79wH/1rmO3YDNWTBWpNmPBA6PeOP
qltC4sXZVeIMOAenZevpmLV4H0ve8gMli7t15yX1nGxlYrfxFYqnj7dXPZfEZP0I
m7rsncVf2asqyRhJ7/ep3xHwAl4929R7CC7hRwBqx9/WOXdyMwACetLnYz5sRCXs
BULlL3S3CQanGTaug+J8t1l/g7HEu1X/ZABQQWx2yROnmN6IiBLsdHUG9AjJP5Ka
mkMzQYyA38rFj5yteKYGtL5dzTp7JBm9xGuXq7f1J4jtDdQi86Z9v8t8hhsWtslq
XNa6H2msmclsFRDorsJjX1L1CJ7LoORfya/m07zvkrjR2GaOk7VZ92IcRy21DL4=
=Klil
-----END PGP SIGNATURE-----
