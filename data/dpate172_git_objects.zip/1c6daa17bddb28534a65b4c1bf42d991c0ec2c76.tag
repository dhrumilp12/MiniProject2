object 88ba2ea3fd0ab4f7f9c916b5313c28faec03d7b4
type commit
tag v68f
tagger James Matthews <jimim@hotmail.co.uk> 1360579890 +0000

Python 68f Release
