object f75af17ecf0f4e180e12dea868a57f7bb44b90e9
type commit
tag v76
tagger James Matthews <jimim@hotmail.co.uk> 1372237253 +0100

Python 76 Release
