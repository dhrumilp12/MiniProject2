object 3e0e622213cc3eefd3695a17297d44844d8a0135
type commit
tag v69g
tagger James Matthews <jimim@hotmail.co.uk> 1360580074 +0000

Python 69g Release
