object 5984916a3ee6efd7c546644490908321f2b77182
type commit
tag v69d
tagger James Matthews <jimim@hotmail.co.uk> 1360580021 +0000

Python 69d Release
