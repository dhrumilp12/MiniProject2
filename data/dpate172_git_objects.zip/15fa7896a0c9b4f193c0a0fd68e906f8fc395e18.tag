object 124f6370eddd7d4e2afef993f0ae3a02d2255def
type commit
tag v0.20.2
tagger Colin Gillespie <csgillespie@gmail.com> 1387476110 +0000

CRAN v0.20.2
