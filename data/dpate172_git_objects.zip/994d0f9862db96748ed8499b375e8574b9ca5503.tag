object ee14eb44273b8ce7808e430e472caf8c960fba68
type commit
tag v68d
tagger James Matthews <jimim@hotmail.co.uk> 1360579831 +0000

Python 68d Release
