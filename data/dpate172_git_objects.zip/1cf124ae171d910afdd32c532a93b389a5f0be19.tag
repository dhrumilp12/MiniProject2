object 6f5bf95372f46146fa981192c0076b4545bed0b3
type commit
tag v1.0-beta.4
tagger Hannu Parviainen <hpparvi@gmail.com> 1475069042 +0100

v1.0-beta.4
