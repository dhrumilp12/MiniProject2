object 1ffc5ed1b14baed1491475a8ad4551f56a0551f5
type commit
tag v0.15.0
tagger Colin Gillespie <csgillespie@gmail.com> 1360790774 +0000

Version 0.15.0 - ctn powerlaws
