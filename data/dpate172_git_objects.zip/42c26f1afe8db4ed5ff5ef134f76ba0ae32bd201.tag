object b8991a0d454ffb6d2c4493c39e44fa454a888d32
type commit
tag v1.2.5
tagger Justin Carpentier <jcarpent@laas.fr> 1507552802 +0200

Release of version 1.2.5.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJZ224iAAoJEA4EpUnaekDlT6cIAJC0B9aCYzEwGnMe9JNGtiZ7
eCQDpu+i3bnsagi/W2no2Zw5J1FADqrKKMAyDgbOhbmk6cyC3NDWLRmUMHAri94R
m3uXzLC+liYgj9RJAIn9revRVf9wyRjCS/h0TyBmHHz3bRQauoSUea2xp77iHj1O
o4j13xJHkG9BwBpcnQqocCQ/yPd0QWXSVs6aLuoagY70aVsci5eCP6j3gyktum8/
RME2sCqthgx/ls1nNsm/2oXnXh5FQ1dGINwBIS7Ezajri6f/kVsuMq7OVqCUpkxo
6vzylViXo/ubMgAMLJybWrn4X9zQCao+fB+2PLM/EAvwsrmhXvtiuLkZs476ho8=
=oBUy
-----END PGP SIGNATURE-----
