object 1cee399324e91896259bfb93c474cf5689d04fd6
type commit
tag v68c
tagger James Matthews <jimim@hotmail.co.uk> 1360579816 +0000

Python 68c Release
