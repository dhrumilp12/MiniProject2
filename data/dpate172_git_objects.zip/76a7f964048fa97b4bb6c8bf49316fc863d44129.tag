object d87eb0ca72aeb788c034998f88605833dd197683
type commit
tag v69f
tagger James Matthews <jimim@hotmail.co.uk> 1360580041 +0000

Python 69f Release
