object f3adfaae6095ef5d26421fec19aa209eca9ab9ba
type commit
tag v70b
tagger James Matthews <jimim@hotmail.co.uk> 1360583958 +0000

Python 70b Release
