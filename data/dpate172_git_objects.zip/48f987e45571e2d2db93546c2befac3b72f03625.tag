object 12748c96433edf5f3f33f0ff9521028a27261773
type commit
tag v70
tagger James Matthews <jimim@hotmail.co.uk> 1360580098 +0000

Python 70 Release
