object 83ac23a8e2b4243a6b17ddf8ef7fd1a69e8417b9
type commit
tag v68g
tagger James Matthews <jimim@hotmail.co.uk> 1360579921 +0000

Python 68g Release
