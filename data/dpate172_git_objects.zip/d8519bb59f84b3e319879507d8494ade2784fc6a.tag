object 1fa5c9594ed7f1bd06eab138cd62bf0420149f66
type commit
tag v0.16.0
tagger Colin Gillespie <csgillespie@gmail.com> 1363292699 +0000

Added vignette
