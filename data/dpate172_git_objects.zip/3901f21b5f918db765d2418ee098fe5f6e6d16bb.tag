object 96e4cbb083c550b2a219444f699d5718d166ae53
type commit
tag v1.2.6
tagger Justin Carpentier <jcarpent@laas.fr> 1515951437 +0100

Release of version 1.2.6.
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1.4.11 (GNU/Linux)

iQEcBAABAgAGBQJaW5VNAAoJEA4EpUnaekDl0xIIAI4Qb+1csTkTmBVn9eFruWMu
cZOrb2ZpAL/NgSON2TRdt05iRCBT+Uz1en8ps/oeetlyHN2QslPy04BRNuvnVrTJ
W3YDeo7zGbsLqXef+/qTvV/krN5OuPkhPUytHaJ64bcqfVudl157qmuSJOZN24KW
W6Uyo1rP/8r+/QFhTqdKDwhEZst60cPM3XJmxWspCFhpKJPTX7iY7eLdTFBH7BQo
+kLx1PcW0R+PFqnFAA2Wts3oSdg3iDwwStKeCRXHnf/g9qPDZlz5DevoCAAJ0SiJ
G3UNTQez2Q5p/yQhUO41naZp+fsFrlZnUIPJRUHLVzWr+IkpqRCI1WoPHZexHpw=
=h0q4
-----END PGP SIGNATURE-----
